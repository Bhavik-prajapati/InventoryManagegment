  <!-- ======= Footer ======= -->
  <footer id="footer" class="footer">
    <div class="copyright">
      &copy; Copyright <strong><span>OM EXIM Corporation</span></strong>. All Rights Reserved
    </div>
    <div class="credits">
      Developed by <a href="#" >SYN Softech Soltions</a>
    </div>
  </footer><!-- End Footer -->